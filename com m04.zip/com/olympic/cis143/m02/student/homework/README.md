# Usecase

This is the homework assignment for M02.

In this assignment, you will rewrite the DeckImpl, from cards, to use an LinkedList. Note that linkedList implements the Deque interface.

# Before You Begin

Please read the following blog post about [using ArrayDeque as a Queue](https://www.baeldung.com/java-array-deque#1-using-arraydeque-as-a-stack)

# You TODO

1. Implement the logic within the DeckLinkedListImpl file using a linked list and use the Deque methods to manage the list.