package com.olympic.cis143.m02.student.cards;

import java.util.Collections;
import java.util.Stack;

public interface Deck {
	public class  DeckImpl {
		private Stack<Card> deck = new Stack<>();
		 
	public Stack<Card> getDeck() {
        return deck;
    }
	 public void shuffle() {;
	    Collections.shuffle(deck);
	    }
	 public boolean hasNext() {
	    	
	    	while(!deck.isEmpty())
	    	{
	    		return true;
	    	}
	    	
	    
	        return false;
	    	
	    }
	 public Card dealCard() {
	    	RuntimeException e = new RuntimeException();
	    	while(hasNext() == true)
	    	{
	    		return deck.pop();
	    	}
	    	if(deck.isEmpty())
	    	{
	    		throw e;
	    	}	
	    	
	        return null;
	    }
}
}