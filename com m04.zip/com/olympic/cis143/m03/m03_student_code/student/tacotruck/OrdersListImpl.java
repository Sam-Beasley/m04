package com.olympic.cis143.m03.m03_student_code.student.tacotruck;
import java.util.ArrayList;
public class OrdersListImpl implements Orders{
	
	private ArrayList<Object> tacoQueue = new ArrayList<Object>();
	//Add order to list
	public void addOrder(TacoImpl tacoOrder) {
		
		tacoQueue.add(tacoOrder);
	}
	//Check of there is an order, return boolean
	public boolean hasNext() {
    	while(!tacoQueue.isEmpty())
    	{
    		return true;
    	}

        return false;
    }
	//Remove and return first element in list
	public TacoImpl closeNextOrder() {
		int element =0;
        return  (TacoImpl) this.tacoQueue.remove(element);
    }
	//Return number of orders left in list
	public int howManyOrders() {
    	int ordersLeft = tacoQueue.size();
        return ordersLeft;
    }

}
