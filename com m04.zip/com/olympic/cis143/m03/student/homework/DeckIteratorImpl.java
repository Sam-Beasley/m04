package com.olympic.cis143.m03.student.homework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

import com.olympic.cis143.m02.student.cards.Card;
import com.olympic.cis143.m02.student.cards.Deck;
import com.olympic.cis143.m02.student.cards.Card.Suit;
import com.olympic.cis143.m02.student.cards.Card.Value;

public class DeckIteratorImpl implements Deck {
	
	private ArrayList<Card> deck = new ArrayList<Card>();
	
	public DeckIteratorImpl(final boolean jokers) {
        this.createDeck(jokers);
    }
	
	//Create Deck of 54 cards if true, 52 if false
	 private void createDeck(final boolean jokers) {
	    	
		//Loop through Card to get enums and add cards
	    	for (Card.Suit suit : Card.Suit.values()) { 
	            for (Card.Value value : Card.Value.values()) {

	                Card card = new Card(suit, value);
	                if(suit != Suit.NONE && value != Value.JOKER)
	                {
	                	deck.add(card);
	                } 
	                //Only add Jokers if jokers == true
	                if(jokers == true && suit == Suit.NONE && value == Value.JOKER)
	                {
	                	deck.add(card);
	                	deck.add(card);
	                }
     
	            }             
	            }
	    	}
	
	 //Get deck
	public ArrayList<Card> getDeck() {
        return deck;
    }
	//Shuffle deck
	public void shuffle() {;
    Collections.shuffle(deck);
    }
	//Check if deck is empty return boolean
	public boolean hasNext() {
    	while(!deck.isEmpty())
    	{
    		return true;
    	}

        return false;
}
	//Deal card if hasNext is true, throw exception if false
	public Card dealCard() {
    	RuntimeException e = new RuntimeException();
    	while(hasNext() == true)
    	{
    		int index = deck.size() -1;
    		return deck.remove(index);
    		
    	}
    	if(deck.isEmpty())
    	{
    		throw e;
    	}	
    	
        return null;
    }
	
	
	
}